# A config file which contains credentials for RDS MySQL instance

db_username = "gu649" 
db_password = "lm990517" 
db_name = "foobar"